import UIKit

var greeting = "Hello, playground"
//MARK: - Start Data
protocol MobileStorage {
    func getAll() -> Set<Mobile>
    func findByImei(_ imei: String) -> Mobile?
    func save(_ mobile: Mobile) throws -> Mobile
    func delete(_ product: Mobile) throws
    func exists(_ product: Mobile) -> Bool
}

struct Mobile: Hashable, Codable {
    let imei: String
    let model: String
}
//

extension FileManager {
    static var documentsDirectoryURL: URL {
        `default`.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
}
enum MyError: Error {
    case notUniqueImei
    case cannotSave
    case cannotDelete
    case cannotFindByImei
}

class IphoneStorage: MobileStorage {
    private var allPhones: Set<Mobile> = []
    
    private let mobilesURL = URL(fileURLWithPath: "SavedMobiles", relativeTo: FileManager.documentsDirectoryURL).appendingPathExtension("json")
    
    
    func save(_ mobile: Mobile) throws -> Mobile {
        guard !allPhones.map({$0.imei}).contains(mobile.imei) else {
            throw MyError.notUniqueImei
        }
        let i = allPhones.insert(mobile)
        guard i.inserted == true else {
            print("phone is not inserted")
            return mobile }
        let encoder = JSONEncoder()
        do {
            let phonesData = try encoder.encode(allPhones)
            try phonesData.write(to: mobilesURL, options: .atomic)
        } catch let error {
            print(error)
        }
        return mobile
    }
    
    func delete(_ product: Mobile) throws {
        allPhones.remove(product)
        let encoder = JSONEncoder()
        do {
            let phonesData = try encoder.encode(allPhones)
            try phonesData.write(to: mobilesURL, options: .atomic)
        } catch let error {
            print(error)
        }
    }
    
    func getAll() -> Set<Mobile> {
        let decoder = JSONDecoder()
        do {
            let mobileData = try Data(contentsOf: mobilesURL)
            let mobiles = try decoder.decode(Set<Mobile>.self, from: mobileData)
            allPhones = mobiles
        } catch let error {
            print("got an error: \(error), \(error.localizedDescription)")
        }
        return allPhones
    }
    
    func findByImei(_ imei: String) -> Mobile? {
        var phone: Mobile?
        for mobile in allPhones {
            if mobile.imei == imei {
                phone = mobile
            }
        }
        return phone
    }
    
    func exists(_ product: Mobile) -> Bool {
        allPhones.contains(product)
    }
}


//MARK: - Testing
let mob = Mobile(imei: "123", model: "iPhone12")
let mob2 = Mobile(imei: "1234", model: "phone25")
let mob3 = Mobile(imei: "123", model: "iPhone1") // duplicate IMEI

var storage = IphoneStorage()
do {
    try storage.save(mob)
} catch let error {
    print(error)
}
do {
    try storage.save(mob2)
} catch let error {
    print(error)
}


do {
    try storage.save(mob3)
} catch let error {
    print(error)
}
//try storage.delete(mob)
//try storage.delete(mob2)
storage.getAll()
storage.exists(mob2)
storage.findByImei("123")
